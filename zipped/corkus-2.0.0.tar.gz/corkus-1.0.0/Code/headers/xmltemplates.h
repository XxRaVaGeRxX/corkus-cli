#ifndef CORKUS_XMLTEMPLATES_H
#define CORKUS_XMLTEMPLATES_H

#include <string>
#include <map>

using std::string;
using std::map;

string getXMLTemplate(const string &skeletonName, const string &style);

#endif
