#ifndef PATH_H
#endif // PATH_H

void addToPath();

#define PATH_H
