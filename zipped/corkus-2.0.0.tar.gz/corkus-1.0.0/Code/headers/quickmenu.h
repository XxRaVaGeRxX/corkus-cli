#ifndef CORKUS_QUICKMENU_H
#define CORKUS_QUICKMENU_H

bool userInput(const std::string &question);

void SkipMenu();

void makeCustomConfig();

void MultiSelMenu();

#endif
